import SwiftUI

struct TasksView: View {
    @State private var viewModel: TasksViewModel

    init(store: LifeStore, appState: AppState) {
        _viewModel = State(initialValue: TasksViewModel(store: store, appState: appState))
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: LifeSpacing.sectionGap) {
                Text("やること")
                    .font(LifeTypography.display)
                    .foregroundStyle(LifeColors.text)
                    .accessibilityAddTraits(.isHeader)

                LifeSegmentControl(TaskSegment.allCases, selection: $viewModel.segment) { $0.title }

                HStack {
                    Spacer()
                    LifeSegmentControl(CompletionFilter.allCases, selection: $viewModel.completion) { $0.title }
                        .fixedSize()
                }

                LifeCard {
                    if viewModel.tasks.isEmpty {
                        LifeEmptyState(systemImage: "checkmark.circle", title: viewModel.emptyTitle)
                    } else {
                        VStack(alignment: .leading, spacing: LifeSpacing.xs) {
                            ForEach(viewModel.tasks) { item in
                                let avatar = viewModel.avatar(for: item)
                                LifeTaskRow(
                                    title: item.title,
                                    detail: viewModel.assigneeText(for: item),
                                    trailing: viewModel.trailingText(for: item),
                                    assigneeName: avatar?.name,
                                    assigneeImage: avatar?.image,
                                    isCompleted: item.isCompleted
                                ) {
                                    withAnimation(.easeInOut(duration: 0.25)) {
                                        viewModel.toggle(item)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .padding(.horizontal, LifeSpacing.screenHorizontal)
            .padding(.vertical, LifeSpacing.screenVertical)
        }
        .background(LifeColors.background.ignoresSafeArea())
        .toolbar(.hidden, for: .navigationBar)
        .quickAddAccessory()
    }
}

#Preview {
    let appState = AppState()
    let store = LifeStore()
    return NavigationStack {
        TasksView(store: store, appState: appState)
    }
    .environment(appState)
    .environment(store)
}
